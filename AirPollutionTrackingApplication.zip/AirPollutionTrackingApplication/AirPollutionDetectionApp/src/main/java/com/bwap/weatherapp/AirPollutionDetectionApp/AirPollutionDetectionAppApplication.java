package com.bwap.weatherapp.AirPollutionDetectionApp;

import org.json.JSONException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirPollutionDetectionAppApplication {


	public static void main(String[] args) throws JSONException {
		SpringApplication.run(AirPollutionDetectionAppApplication.class, args);

	}

}
